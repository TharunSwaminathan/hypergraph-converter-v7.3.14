import { createHash, randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import { canonicalOrdinaryGraphToCsr } from "../../../src/candy/adapters/csrAdapter.js";
import { validateAlgorithmRequest, validateAlgorithmResult, validateGraphSnapshot, validateGraphUpdateBatch } from "../../../src/candy/contracts/algorithmSchemas.js";
import { CANDY_SCHEMA_VERSIONS } from "../../../src/candy/contracts/schemaVersions.js";
import { CANDY_ERROR_CODES, CandyContractError } from "../../../src/candy/contracts/errorClasses.js";
import { JOB_SUBMIT_SCHEMA_VERSION } from "../config.js";
import { parseNativeResult, serializeNativeSsspRequest } from "../backends/nativeRequestAdapter.js";
import { NativeProcessRunner } from "../backends/nativeProcessRunner.js";
import { MOTIF_ALGORITHM, validateRuntimeMotifRequest } from "../../../src/candy/contracts/runtimeMotif.js";
import { prepareMotifJob, acceptMotifNative } from "../backends/motifJobAdapter.js";
import { verifyQualifiedMotifBackend } from "../capabilities/motifQualification.js";

const TERMINAL = new Set(["completed", "failed", "cancelled"]);
const SUBMIT_KEYS = new Set(["schemaVersion", "request", "graphSnapshot", "graphArtifactId", "propertyStateArtifactId", "updateBatchArtifactId"]);
function exactSubmit(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_GRAPH_SCHEMA, "Job submission must be an object.");
  const unknown = Object.keys(value).filter(key => !SUBMIT_KEYS.has(key));
  if (unknown.length || value.schemaVersion !== JOB_SUBMIT_SCHEMA_VERSION) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_GRAPH_SCHEMA, "Job submission uses missing, unknown, or incompatible fields.", { unknown });
}

function stable(value) {
  if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
  return JSON.stringify(value);
}

function parseJson(bytes, classification = CANDY_ERROR_CODES.INVALID_GRAPH_SCHEMA) {
  try { return JSON.parse(bytes.toString("utf8")); }
  catch { throw new CandyContractError(classification, "Immutable CANDY artifact is not valid JSON."); }
}

function validatePriorState(value, request, csr) {
  const keys = ["schemaVersion", "sessionId", "graphId", "graphVersion", "algorithmStateVersion", "sourceVertexId", "objective", "distances", "parents"];
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some(key => !keys.includes(key)) || keys.some(key => !Object.hasOwn(value, key))) {
    throw new CandyContractError(CANDY_ERROR_CODES.STALE_PROPERTY_STATE, "Prior property-state artifact is malformed.");
  }
  if (value.schemaVersion !== "candy.property-state/1" || value.graphId !== request.graphRef.graphId || value.graphVersion !== request.graphRef.graphVersion || value.sourceVertexId !== request.parameters.sourceVertexId || value.objective !== request.parameters.objective || !Number.isSafeInteger(value.algorithmStateVersion) || value.algorithmStateVersion < 1) {
    throw new CandyContractError(CANDY_ERROR_CODES.STALE_PROPERTY_STATE, "Prior property state does not match the exact graph, source, objective, and version.");
  }
  if (!Array.isArray(value.distances) || !Array.isArray(value.parents) || value.distances.length !== csr.vertexCount || value.parents.length !== csr.vertexCount) throw new CandyContractError(CANDY_ERROR_CODES.STALE_PROPERTY_STATE, "Prior property-state vectors do not match the graph mapping.");
  return value;
}

function validateUpdateEdges(value, maxUpdates) {
  if (!value || value.schemaVersion !== "candy.edge-updates/1" || !Array.isArray(value.insertions) || !Array.isArray(value.deletions)) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_UPDATE_BATCH, "Update edge artifact is malformed.");
  if (value.insertions.length + value.deletions.length > maxUpdates) throw new CandyContractError(CANDY_ERROR_CODES.RESOURCE_LIMIT, "Update batch exceeds its configured limit.");
  const baseEdge = edge => edge && typeof edge === "object" && !Array.isArray(edge) && Object.hasOwn(edge, "source") && Object.hasOwn(edge, "target");
  const validDeletion = edge => baseEdge(edge) && Object.keys(edge).length === 2 && Object.keys(edge).every(key => ["source", "target"].includes(key));
  const validInsertion = edge => baseEdge(edge) && Object.keys(edge).length === 3 && Object.keys(edge).every(key => ["source", "target", "weight"].includes(key)) && Number.isSafeInteger(edge.weight) && edge.weight >= 0 && edge.weight <= 2_147_483_647;
  if (!value.deletions.every(validDeletion) || !value.insertions.every(validInsertion)) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_UPDATE_BATCH, "Update edges are malformed or use unsupported weights.");
  return value;
}

function publicJob(job) {
  return {
    schemaVersion: "candy.job-status/1",
    jobId: job.jobId,
    requestHash: job.requestHash,
    status: job.status,
    algorithm: job.request.algorithm,
    backend: job.request.backend,
    mode: job.request.mode,
    graphRef: { ...job.request.graphRef },
    sourceVertexId: job.request.parameters?.sourceVertexId,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    resultRef: job.resultRef ?? null,
    error: job.error ? structuredClone(job.error) : null,
    lifecycle: Object.freeze([...(job.lifecycle ?? [job.status])].slice(-12)),
  };
}

export class JobManager {
  constructor({ artifactStore, config }) {
    this.artifactStore = artifactStore;
    this.config = config;
    this.jobs = new Map();
    this.runtimeSessionId = randomUUID();
    this.motifQueue = Promise.resolve();
    this.executions = new Set();
    this.closing = false;
    this.admissions = 0;
    this.admissionTasks = new Set();
    this.maintenance = Promise.resolve();
    this.cleanupError = null;
    this.runner = config.nativeRunner ?? new NativeProcessRunner({ runtimeRoot: config.runtimeRoot, stdoutBytes: config.limits.stdoutBytes, stderrBytes: config.limits.stderrBytes, cudaBackendDiscovery: config.cudaBackendDiscovery, motifBackendDiscovery: config.motifBackendDiscovery });
  }

  async submit(payload) {
    if(this.closing || this.cleanupError)throw new CandyContractError(CANDY_ERROR_CODES.BACKEND_UNAVAILABLE,"Runtime is shutting down or requires cleanup.");
    const active=[...this.jobs.values()].filter(job=>!job.finished).length;
    if(active+this.admissions>=Math.min(this.config.limits.maxJobs,this.config.limits.maxActiveJobs))throw new CandyContractError(CANDY_ERROR_CODES.RESOURCE_LIMIT,"Runtime active/backlog admission limit reached.");
    this.admissions++;
    let settled;
    const admission=new Promise(resolve=>{settled=resolve;});this.admissionTasks.add(admission);
    const owner=randomUUID();
    try { await this.prune(); return await this.submitAccepted(payload,owner); }
    finally {
      try { if(!this.jobs.has(owner))await this.artifactStore.release(owner); }
      finally { this.admissions--;this.admissionTasks.delete(admission);settled(); }
    }
  }

  async submitAccepted(payload, owner) {
    exactSubmit(payload);
    if (this.closing) throw new CandyContractError(CANDY_ERROR_CODES.BACKEND_UNAVAILABLE,"Runtime is shutting down.");
    payload = JSON.parse(JSON.stringify(payload));
    const snapshot = validateGraphSnapshot(payload.graphSnapshot);
    const motif = payload.request?.algorithm === MOTIF_ALGORITHM;
    const request = motif ? validateRuntimeMotifRequest(payload.request,snapshot) : validateAlgorithmRequest(payload.request, snapshot);
    if (payload.graphArtifactId !== snapshot.canonicalArtifactRef.id) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_GRAPH_SCHEMA, "Graph artifact does not match GraphSnapshot.canonicalArtifactRef.");
    this.artifactStore.pin([payload.graphArtifactId,payload.propertyStateArtifactId,payload.updateBatchArtifactId].filter(Boolean),owner);
    if (motif) {
      if (Object.hasOwn(payload,"propertyStateArtifactId") || request.mode === "STATIC" && Object.hasOwn(payload,"updateBatchArtifactId")
        || request.mode === "INCREMENTAL" && payload.updateBatchArtifactId !== request.updateRef.artifactId) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_UPDATE_BATCH,"Motif submission contains an incompatible prior-state or update binding.");
      if (request.mode === "INCREMENTAL") this.artifactStore.metadata(request.updateRef.artifactId);
      const ready = await verifyQualifiedMotifBackend(this.config,request.backend);
      if (!ready.available || ready.device?.id !== request.deviceId) throw new CandyContractError(CANDY_ERROR_CODES.BACKEND_UNAVAILABLE,"The exact requested qualified motif backend/device is unavailable.");
    }
    if (this.closing) throw new CandyContractError(CANDY_ERROR_CODES.BACKEND_UNAVAILABLE, "Runtime shut down during backend discovery.");
    if (payload.graphArtifactId !== snapshot.canonicalArtifactRef.id) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_GRAPH_SCHEMA, "Graph artifact does not match GraphSnapshot.canonicalArtifactRef.");
    this.artifactStore.metadata(payload.graphArtifactId);
    const requestHash = `sha256:${createHash("sha256").update(stable({ request, snapshot, graphArtifactId: payload.graphArtifactId, propertyStateArtifactId: payload.propertyStateArtifactId ?? null, updateBatchArtifactId: payload.updateBatchArtifactId ?? null })).digest("hex")}`;
    // Preserve the legacy SSSP exact-request retry contract within bounded
    // retention. Motif analysis deduplicates in-flight requests only. No result
    // is relabelled with another request/job/session identity.
    const duplicate = [...this.jobs.values()].find(job => job.requestHash === requestHash && (!TERMINAL.has(job.status) || !motif && job.status==="completed"));
    if (duplicate) return publicJob(duplicate);
    const now = new Date().toISOString();
    const job = { jobId: owner, requestHash, request, snapshot, payload, status: "queued", lifecycle: ["queued"], createdAt: now, updatedAt: now, controller: new AbortController(), resultRef: null, error: null, createdArtifacts:[],finished:false };
    const expire=()=>{job.deadlineError=new CandyContractError(CANDY_ERROR_CODES.PROCESS_TIMEOUT,"Runtime queue or end-to-end deadline exceeded.");job.controller.abort();};
    job.queueTimer=setTimeout(expire,this.config.limits.queueWaitMs);
    job.deadlineTimer=setTimeout(expire,this.config.limits.jobDeadlineMs);
    this.jobs.set(job.jobId, job);
    queueMicrotask(() => {
      // One bounded FIFO execution lane for every backend, including SSSP.
      const execution = this.motifQueue.then(() => this.execute(job));
      this.motifQueue = execution.catch(() => {});
      this.executions.add(execution);
      execution.finally(() => this.executions.delete(execution)).catch(() => {});
    });
    return publicJob(job);
  }

  get(jobId) {
    const job = this.jobs.get(jobId);
    if (!job) throw this.unknownJob();
    return publicJob(job);
  }

  result(jobId) {
    const job = this.jobs.get(jobId);
    if (!job) throw this.unknownJob();
    if (job.status !== "completed" || !job.fullResult) throw new CandyContractError(job.status === "cancelled" ? CANDY_ERROR_CODES.JOB_CANCELLED : CANDY_ERROR_CODES.ALGORITHM_FAILURE, "CANDY job has no accepted result.");
    return JSON.parse(JSON.stringify(job.fullResult));
  }

  cancel(jobId) {
    const job = this.jobs.get(jobId);
    if (!job) throw this.unknownJob();
    if (job.status === "cancelled" || job.status === "cancelling") return publicJob(job);
    if (TERMINAL.has(job.status)) return publicJob(job);
    this.transition(job, job.status === "queued" ? "cancelled" : "cancelling");
    job.controller.abort();
    return publicJob(job);
  }

  transition(job, status) {
    job.status = status;
    if (job.lifecycle.at(-1) !== status) job.lifecycle.push(status);
    job.updatedAt = new Date().toISOString();
  }

  unknownJob() { return Object.assign(new CandyContractError(CANDY_ERROR_CODES.INVALID_GRAPH_SCHEMA,"Job is unknown or expired; it cannot supply a result."),{httpStatus:404}); }

  prune() {
    const operation=this.maintenance.then(async()=>{
      const terminal=[...this.jobs.values()].filter(job=>job.finished);
      let bytes=terminal.reduce((n,j)=>n+j.retainedBytes,0);
      while(terminal.length>Math.min(this.config.limits.maxJobs,this.config.limits.maxTerminalJobs) || bytes>this.config.limits.terminalBytes) {
        const job=terminal.shift();
        if(!this.jobs.has(job.jobId)){bytes-=job.retainedBytes;continue;}
        this.jobs.delete(job.jobId); // lookup fails before any associated file can expire
        await this.artifactStore.release(job.jobId,job.createdArtifacts);
        bytes-=job.retainedBytes;
      }
    });
    this.maintenance=operation.catch(error=>{this.cleanupError=error;});
    return operation;
  }

  async putJobArtifact(job, bytes, mediaType) {
    const artifact=await this.artifactStore.put(bytes,mediaType,{owner:job.jobId});
    job.createdArtifacts.push(artifact.id); return artifact;
  }

  async execute(job) {
    let workspace;
    let motifTerminal = null;
    let cleanupFailed = false;
    try {
      if(this.cleanupError)throw new CandyContractError(CANDY_ERROR_CODES.BACKEND_UNAVAILABLE,"Runtime requires cleanup before queued work can execute.");
      if (job.controller.signal.aborted) throw job.deadlineError ?? new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED,"Job was cancelled while queued.");
      clearTimeout(job.queueTimer);
      this.transition(job, "preparing");
      if (job.request.algorithm === MOTIF_ALGORITHM) {
        const packed = await prepareMotifJob(job,this.artifactStore);
        workspace = await this.artifactStore.ownedRoot.createWorkspace();
        const requestPath = join(workspace,"request.txt");
        await writeFile(requestPath,packed.text,{encoding:"utf8",mode:0o600});
        if (job.controller.signal.aborted) throw new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED,"Motif job was cancelled before native execution.");
        this.transition(job,"running");
        const processResult = await this.runner.run({ backend: job.request.backend, requestPath, timeoutMs: job.request.timeoutMs, deviceId: job.request.deviceId, signal: job.controller.signal });
        if (job.controller.signal.aborted) throw new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED,"Motif job was cancelled before result validation.");
        this.transition(job,"validating");
        const result = acceptMotifNative(processResult,packed,job,this.runtimeSessionId);
        const bytes = Buffer.from(JSON.stringify(result));
        if (bytes.length > this.config.limits.resultBytes) throw new CandyContractError(CANDY_ERROR_CODES.RESOURCE_LIMIT,"Motif result exceeds the configured size limit.");
        const artifact = await this.putJobArtifact(job,bytes,"application/vnd.candy.result+json");
        if (job.controller.signal.aborted) throw new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED,"Motif job was cancelled before result acceptance.");
        job.fullResult = JSON.parse(JSON.stringify({ ...result, resultArtifactRef: artifact }));
        job.resultRef = artifact.id;
        motifTerminal = "completed";
        return;
      }
      const graph = parseJson(await this.artifactStore.read(job.payload.graphArtifactId));
      if (graph.graphType !== job.snapshot.graphType) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_GRAPH_TYPE, "Canonical graph artifact type does not match its snapshot.");
      const csr = canonicalOrdinaryGraphToCsr(graph, { limits: { maxVertices: this.config.limits.maxVertices, maxEdges: this.config.limits.maxEdges } });
      if (job.request.backend === "LOCAL_CUDA" && csr.vertexCount > this.config.limits.maxCudaVertices) throw new CandyContractError(CANDY_ERROR_CODES.RESOURCE_LIMIT, "Graph exceeds the qualified CUDA vertex limit.");
      if (csr.vertexCount !== job.snapshot.vertexCount || csr.edgeCount !== job.snapshot.edgeCount) throw new CandyContractError(CANDY_ERROR_CODES.STALE_GRAPH_VERSION, "Canonical graph cardinality changed after job authorization.");
      let priorState = null;
      let updates = null;
      if (job.request.mode !== "STATIC") {
        if (!job.payload.propertyStateArtifactId || !job.payload.updateBatchArtifactId) throw new CandyContractError(CANDY_ERROR_CODES.STALE_PROPERTY_STATE, "Incremental execution requires prior-state and update artifacts.");
        priorState = validatePriorState(parseJson(await this.artifactStore.read(job.payload.propertyStateArtifactId), CANDY_ERROR_CODES.STALE_PROPERTY_STATE), job.request, csr);
        const descriptor = parseJson(await this.artifactStore.read(job.payload.updateBatchArtifactId), CANDY_ERROR_CODES.INVALID_UPDATE_BATCH);
        validateGraphUpdateBatch(descriptor, job.request.graphRef);
        this.artifactStore.pin([descriptor.insertionsArtifactRef.id,descriptor.deletionsArtifactRef.id],job.jobId);
        if (descriptor.updateBatchId !== job.request.updateBatchRef.updateBatchId) throw new CandyContractError(CANDY_ERROR_CODES.INVALID_UPDATE_BATCH, "Update artifact identity does not match the request.");
        const insertionArtifact = parseJson(await this.artifactStore.read(descriptor.insertionsArtifactRef.id), CANDY_ERROR_CODES.INVALID_UPDATE_BATCH);
        const deletionArtifact = parseJson(await this.artifactStore.read(descriptor.deletionsArtifactRef.id), CANDY_ERROR_CODES.INVALID_UPDATE_BATCH);
        updates = validateUpdateEdges({ schemaVersion: "candy.edge-updates/1", insertions: insertionArtifact.edges, deletions: deletionArtifact.edges }, this.config.limits.maxUpdates);
      }
      const mappingArtifact = await this.putJobArtifact(job,Buffer.from(JSON.stringify({ schemaVersion: CANDY_SCHEMA_VERSIONS.VERTEX_MAPPING, ordering: csr.mapping.ordering, entries: csr.mapping.entries })), "application/json");
      workspace = await this.artifactStore.ownedRoot.createWorkspace();
      const requestPath = join(workspace, "request.txt");
      await writeFile(requestPath, serializeNativeSsspRequest({ request: job.request, graphSnapshot: job.snapshot, csr, priorState, updates }), { encoding: "utf8", mode: 0o600 });
      if (job.controller.signal.aborted) throw new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED, "CANDY job was cancelled before native execution.");
      this.transition(job, "running");
      const processResult = await this.runner.run({ backend: job.request.backend, requestPath, timeoutMs: job.request.resourceHints.timeoutMs, signal: job.controller.signal });
      if (job.controller.signal.aborted) throw new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED, "CANDY job was cancelled before result acceptance.");
      this.transition(job, "validating");
      const native = parseNativeResult(processResult.stdout);
      if (processResult.exitCode !== 0) throw new CandyContractError(CANDY_ERROR_CODES.PROCESS_CRASH, "Native SSSP returned success content with a non-zero exit status.", { exitCode: processResult.exitCode });
      // The frozen Scope 1 OpenMP protocol predates the backend output field.
      // Its identity comes from the fixed selected executable; an explicit
      // conflicting backend remains invalid, and CUDA must always declare it.
      const backendMatches = native.backend === job.request.backend || job.request.backend === "LOCAL_OPENMP" && !Object.hasOwn(native, "backend");
      if (!backendMatches || native.graphId !== job.request.graphRef.graphId || native.graphVersion !== job.request.graphRef.graphVersion || native.mode !== job.request.mode || native.source !== csr.mapping.toNative(job.request.parameters.sourceVertexId)) throw new CandyContractError(CANDY_ERROR_CODES.RESULT_VALIDATION_FAILURE, "Native result identity does not match the authorized job.");
      const fullArtifact = await this.putJobArtifact(job,Buffer.from(JSON.stringify({ ...native, vertexMapping: csr.mapping.entries })), "application/vnd.candy.result+json");
      const result = {
        schemaVersion: CANDY_SCHEMA_VERSIONS.ALGORITHM_RESULT,
        jobId: job.jobId,
        requestId: job.request.requestId,
        algorithm: "SSSP",
        backend: job.request.backend,
        mode: job.request.mode,
        inputGraphRef: job.request.graphRef,
        resultType: "ShortestPathTree",
        execution: { status: "completed", exitCode: 0 },
        modelSummary: { sourceVertexId: job.request.parameters.sourceVertexId, reachableCount: native.reachableCount, unreachableCount: native.unreachableCount, affectedCount: native.affectedVertices, runtimeMs: Number(native.metrics?.computeMs ?? native.metrics?.kernelMs ?? 0), validationStatus: native.validation?.status ?? "not_requested" },
        resultArtifactRef: fullArtifact,
        mappingArtifactRef: mappingArtifact,
        metrics: native.metrics ?? {},
        validation: { status: native.validation?.status ?? "not_requested", method: job.request.mode === "COMPARE" ? "native_static_reference" : "native_semantic_validation" },
        warnings: [],
      };
      validateAlgorithmResult(result);
      if (job.controller.signal.aborted) throw new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED, "CANDY job was cancelled before result acceptance.");
      job.fullResult = result;
      job.resultRef = fullArtifact.id;
      motifTerminal = "completed";
    } catch (error) {
      if (job.deadlineError) {
        job.error=job.deadlineError.toJSON();motifTerminal="failed";
      } else if (job.controller.signal.aborted || error?.code === CANDY_ERROR_CODES.JOB_CANCELLED) {
        job.error = new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED, "CANDY job was cancelled.").toJSON();
        motifTerminal = "cancelled";
      } else {
        const safe = error instanceof CandyContractError ? error : new CandyContractError(CANDY_ERROR_CODES.ALGORITHM_FAILURE, "CANDY job failed during controlled execution.");
        job.error = safe.toJSON();
        motifTerminal = "failed";
      }
    } finally {
      if (workspace) {
        try { await this.artifactStore.ownedRoot.removeWorkspace(workspace); }
        catch (error) {
          cleanupFailed = true;
          job.fullResult = null;
          job.resultRef = null;
          job.error = new CandyContractError(CANDY_ERROR_CODES.ALGORITHM_FAILURE, "Native request cleanup failed; no result was accepted.",{cleanupCode:error.code ?? "UNKNOWN"}).toJSON();
          motifTerminal = "failed";
          this.cleanupError=error;
        }
      }
      // An end-to-end deadline may expire while asynchronous cleanup runs.
      // Cleanup failure remains primary; no expired result may publish success.
      clearTimeout(job.queueTimer); clearTimeout(job.deadlineTimer);
      if(job.deadlineError){
        motifTerminal="failed";job.fullResult=null;job.resultRef=null;
        if(!cleanupFailed)job.error=job.deadlineError.toJSON();
      }
      if (motifTerminal) {
        if (job.controller.signal.aborted && !job.deadlineError) {
          motifTerminal = "cancelled";
          job.fullResult = null;
          job.resultRef = null;
          job.error = new CandyContractError(CANDY_ERROR_CODES.JOB_CANCELLED, "CANDY job was cancelled.").toJSON();
        }
        this.transition(job, motifTerminal);
      }
      if(job.status!=="completed") {
        job.fullResult=null;job.resultRef=null;
        try { await this.artifactStore.release(job.jobId,job.createdArtifacts); }
        catch(error){this.cleanupError=error;job.error=new CandyContractError(CANDY_ERROR_CODES.ALGORITHM_FAILURE,"Artifact cleanup failed; Runtime requires cleanup.").toJSON();this.transition(job,"failed");}
      }
      job.finished=true;
      job.retainedBytes=Buffer.byteLength(JSON.stringify({request:job.request,snapshot:job.snapshot,payload:job.payload,result:job.fullResult,error:job.error}));
      this.artifactStore.retainTerminal(job.jobId,job.createdArtifacts,()=>{
        this.jobs.delete(job.jobId);job.fullResult=null;job.resultRef=null;
      });
      try { await this.prune(); } catch { /* cleanupError blocks admission; close surfaces it. */ }
    }
  }

  async close() {
    this.closing = true;
    await Promise.all([...this.admissionTasks]);
    for (const job of this.jobs.values()) if (!TERMINAL.has(job.status)) this.cancel(job.jobId);
    // Submit schedules execution in a microtask; drain that scheduling first.
    await Promise.resolve();
    await Promise.allSettled([...this.executions]);
    await this.maintenance;
    if(this.cleanupError)throw new CandyContractError(CANDY_ERROR_CODES.ALGORITHM_FAILURE,"Runtime cleanup failed; owned files require operator review.",{cleanupCode:this.cleanupError.code ?? "UNKNOWN"});
  }
}
